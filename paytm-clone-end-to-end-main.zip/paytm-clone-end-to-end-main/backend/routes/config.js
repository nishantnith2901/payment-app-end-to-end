const jwtSecret="satyam@1234";
module.exports = jwtSecret;